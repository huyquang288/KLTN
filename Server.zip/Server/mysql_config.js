module.exports = {
  mySQLConfiguration: function () {
    return {
        hostname:"127.0.0.1",
        database:"messenger_developer",
        user: "root",
        password: "",
        port: "3306"
    };

  },
};